public class palindrom {

	public static void main(String[] args) {
		
		char [] polindrom;

		polindrom = new char[];

	}
	
}