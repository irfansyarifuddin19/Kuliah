import java.util.Scanner;

public class responsi1_2 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		// input mahasiswa

		// mahasiswa 1
		System.out.print("Nama : ");
		String mahasiswa1 = sc.nextLine();
		System.out.print("Jurusan : ");
		String jurusan1 = sc.nextLine();
		System.out.print("Nilai Tugas : ");
		double NilaiTugas1 = sc.nextDouble();
		System.out.print("Nilai UTS : ");
		double NilaiUTS1 = sc.nextDouble();
		System.out.print("Nilai UAS : ");
		double NilaiUAS1 = sc.nextDouble();
		System.out.print("Nilai Praktek : ");
		double NilaiPrak1 = sc.nextDouble();

		System.out.println();
		// mahasiswa 2
		System.out.print("Nama : ");
		String mahasiswa2 = sc.nextLine();
		System.out.print("Jurusan : ");
		String jurusan2 = sc.nextLine();
		System.out.print("Nilai Tugas : ");
		double NilaiTugas2 = sc.nextDouble();
		System.out.print("Nilai UTS : ");
		double NilaiUTS2 = sc.nextDouble();
		System.out.print("Nilai UAS : ");
		double NilaiUAS2 = sc.nextDouble();
		System.out.print("Nilai Praktek : ");
		double NilaiPrak2 = sc.nextDouble();

		System.out.println();
		// mahasiswa 3
		System.out.print("Nama : ");
		String mahasiswa3 = sc.nextLine();
		System.out.print("Jurusan : ");
		String jurusan3 = sc.nextLine();
		System.out.print("Nilai Tugas : ");
		double NilaiTugas3 = sc.nextDouble();
		System.out.print("Nilai UTS : ");
		double NilaiUTS3 = sc.nextDouble();
		System.out.print("Nilai UAS : ");
		double NilaiUAS3 = sc.nextDouble();
		System.out.print("Nilai Praktek : ");
		double NilaiPrak3 = sc.nextDouble();

		System.out.println();
		


	}

}